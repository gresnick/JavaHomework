package za.co.resnick.amazonhomework.helpers;

import junit.framework.TestCase;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.JUnitCore;

/**
 * This class provides a suite of JUnit test cases that exercise the
 * {@link StreamHelper} class.
 * <p>
 * Note that, due to time constraints, this JUnit is incomplete (i.e.
 * technical debt). 
 * 
 * @author Gary Resnick (gary@resnick.co.za)
 */
public class Test_StreamHelper 
extends TestCase
{
	@Before
	public void setUp()
	throws Exception
	{
		//
		// Not used
		//
	}
	
	/*------------------------------------------------------------------------*/
	
	@After
	public void tearDown()
	throws Exception
	{
		//
		// Not used
		//
	}
	
	/*------------------------------------------------------------------------*/
	
	@Test
	public void test_method()
	throws Exception
	{
		
	}
	
	/*------------------------------------------------------------------------*/
	
	/**
	 * Allows running this test suite from the command line
	 */
	public static void main(String... args)
	{
		JUnitCore.main(Test_StreamHelper.class.getName());
	}
}